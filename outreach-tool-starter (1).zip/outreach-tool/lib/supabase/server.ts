import { createClient } from '@supabase/supabase-js';

/**
 * Server-side Supabase client using the service role key — for use only
 * in API routes and job scripts (never expose this key to the browser).
 */
export function getSupabaseServerClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error(
      'Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env'
    );
  }

  return createClient(url, serviceKey, {
    auth: { persistSession: false },
  });
}
