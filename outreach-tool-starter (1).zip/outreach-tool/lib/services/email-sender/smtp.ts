import nodemailer, { Transporter } from 'nodemailer';
import type { EmailSender, EmailMessage, SendResult } from './index';

export class SmtpEmailSender implements EmailSender {
  private transporter: Transporter;
  private fromName: string;
  private fromEmail: string;

  constructor() {
    const host = process.env.SMTP_HOST;
    const port = Number(process.env.SMTP_PORT || 587);
    const secure = process.env.SMTP_SECURE === 'true';
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    if (!host || !user || !pass) {
      throw new Error(
        'SMTP is not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS in .env'
      );
    }

    this.transporter = nodemailer.createTransport({
      host,
      port,
      secure,
      auth: { user, pass },
    });

    this.fromName = process.env.SMTP_FROM_NAME || '';
    this.fromEmail = process.env.SMTP_FROM_EMAIL || user;
  }

  async send(message: EmailMessage): Promise<SendResult> {
    try {
      const info = await this.transporter.sendMail({
        from: this.fromName
          ? `"${this.fromName}" <${this.fromEmail}>`
          : this.fromEmail,
        to: message.to,
        subject: message.subject,
        html: message.html,
        text: message.text,
        headers: message.headers,
      });

      return { success: true, messageId: info.messageId };
    } catch (err: any) {
      return { success: false, error: err?.message || 'Unknown SMTP error' };
    }
  }
}
