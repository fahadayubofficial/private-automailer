/**
 * EmailSender abstraction.
 *
 * Day 1 implementation (smtp.ts) sends through your own mailbox via
 * Nodemailer — free, no third-party sending service required.
 *
 * If you ever want to add a paid provider (SendGrid, SES, Postmark, etc.),
 * add a new file here implementing this same interface and switch the
 * factory below. Nothing else in the app needs to change.
 */

export interface EmailMessage {
  to: string;
  subject: string;
  html: string;
  text?: string;
  headers?: Record<string, string>;
}

export interface SendResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

export interface EmailSender {
  send(message: EmailMessage): Promise<SendResult>;
}

export function getEmailSender(): EmailSender {
  // Day 1: always SMTP (your existing mailbox). This is the only
  // implementation wired up right now, but the factory pattern is here
  // so a future provider is a one-line swap, e.g.:
  //
  // if (process.env.EMAIL_PROVIDER === 'sendgrid') return new SendgridEmailSender();
  const { SmtpEmailSender } = require('./smtp');
  return new SmtpEmailSender();
}
