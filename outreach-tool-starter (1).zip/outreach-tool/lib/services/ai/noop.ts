import type { AIProvider } from './index';

export class NoopAIProvider implements AIProvider {
  enabled = false;

  async generateVariant(_prompt: string): Promise<string> {
    throw new Error(
      'AI features are disabled (no ANTHROPIC_API_KEY set). ' +
        'This is expected — the app runs fully without AI. ' +
        'UI code should check `provider.enabled` before offering AI actions.'
    );
  }
}
