import type { AIProvider } from './index';

export class ClaudeAIProvider implements AIProvider {
  enabled = true;
  private client: any;

  constructor() {
    // Lazy import so the SDK is only required if this class is instantiated,
    // which only happens when ANTHROPIC_API_KEY is set (see index.ts).
    const Anthropic = require('@anthropic-ai/sdk');
    this.client = new Anthropic.default({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
  }

  async generateVariant(prompt: string): Promise<string> {
    const response = await this.client.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
    });

    const textBlock = response.content.find((b: any) => b.type === 'text');
    return textBlock?.text ?? '';
  }
}
