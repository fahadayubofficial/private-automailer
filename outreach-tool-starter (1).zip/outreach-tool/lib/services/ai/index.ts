/**
 * Optional AI provider abstraction.
 *
 * The app must work fully with AI disabled. getAIProvider() automatically
 * returns a no-op implementation unless ANTHROPIC_API_KEY is set — so
 * nothing else in the codebase needs to check "is AI enabled?" itself,
 * it just calls the interface and gets a safe default back.
 */

export interface AIProvider {
  readonly enabled: boolean;
  generateVariant(prompt: string): Promise<string>;
}

export function getAIProvider(): AIProvider {
  if (process.env.ANTHROPIC_API_KEY) {
    const { ClaudeAIProvider } = require('./claude');
    return new ClaudeAIProvider();
  }
  const { NoopAIProvider } = require('./noop');
  return new NoopAIProvider();
}
