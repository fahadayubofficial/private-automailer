import dns from 'node:dns/promises';
import type { EmailValidator, ValidationResult } from './index';
import { isDisposableDomain } from './disposable-list';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export class DnsMxEmailValidator implements EmailValidator {
  async validate(email: string): Promise<ValidationResult> {
    const reasons: string[] = [];

    if (!EMAIL_REGEX.test(email)) {
      return { valid: false, reasons: ['invalid_syntax'] };
    }

    const domain = email.split('@')[1].toLowerCase();

    if (isDisposableDomain(domain)) {
      reasons.push('disposable_domain');
    }

    try {
      const records = await dns.resolveMx(domain);
      if (!records || records.length === 0) {
        reasons.push('no_mx_record');
      }
    } catch {
      reasons.push('no_mx_record');
    }

    return { valid: reasons.length === 0, reasons };
  }
}
