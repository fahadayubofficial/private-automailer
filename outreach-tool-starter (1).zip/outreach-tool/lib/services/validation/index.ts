/**
 * Email validation abstraction. All Day 1 checks are free and local:
 * regex syntax check, DNS MX lookup (native Node `dns`), and an
 * open-source disposable-domain list. No paid verification API
 * (e.g. ZeroBounce, NeverBounce) is required for the app to function.
 */

export interface ValidationResult {
  valid: boolean;
  reasons: string[]; // e.g. ['invalid_syntax'], ['no_mx_record'], ['disposable_domain']
}

export interface EmailValidator {
  validate(email: string): Promise<ValidationResult>;
}

export function getEmailValidator(): EmailValidator {
  const { DnsMxEmailValidator } = require('./dns-mx');
  return new DnsMxEmailValidator();
}
