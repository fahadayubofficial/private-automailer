/**
 * Disposable email domain detection.
 *
 * This starter set is intentionally small. For real coverage, pull an
 * open-source list such as:
 *   https://github.com/disposable-email-domains/disposable-email-domains
 * at build/deploy time (or on a daily job) and load it into this Set —
 * do NOT fetch it on every request, to keep this free and fast.
 *
 * Suggested approach later:
 *   1. Add a `disposable_domains` table in Supabase.
 *   2. A daily job (lib/jobs) downloads the latest list and upserts it.
 *   3. This function checks the DB/cache instead of the hardcoded set.
 */

const STARTER_DISPOSABLE_DOMAINS = new Set([
  'mailinator.com',
  'guerrillamail.com',
  '10minutemail.com',
  'tempmail.com',
  'yopmail.com',
  'trashmail.com',
  'throwawaymail.com',
  'fakeinbox.com',
]);

export function isDisposableDomain(domain: string): boolean {
  return STARTER_DISPOSABLE_DOMAINS.has(domain.toLowerCase());
}
