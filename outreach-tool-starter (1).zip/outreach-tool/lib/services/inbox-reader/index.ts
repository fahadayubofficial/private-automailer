/**
 * InboxReader abstraction — used for reply/bounce detection by polling
 * your existing mailbox over IMAP. Free, no third-party inbound-parsing
 * service required (e.g. no SendGrid Inbound Parse, no Mailgun routes).
 */

export interface InboxMessageSummary {
  uid: number;
  from: string;
  subject: string;
  snippet: string;
  inReplyTo?: string;
  receivedAt: Date;
  isBounce: boolean;
}

export interface InboxReader {
  fetchNewMessages(sinceUid?: number): Promise<InboxMessageSummary[]>;
}

export function getInboxReader(): InboxReader {
  const { ImapInboxReader } = require('./imap');
  return new ImapInboxReader();
}
