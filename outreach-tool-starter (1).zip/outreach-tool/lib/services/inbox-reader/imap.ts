import { ImapFlow } from 'imapflow';
import { simpleParser } from 'mailparser';
import type { InboxReader, InboxMessageSummary } from './index';

const BOUNCE_KEYWORDS = [
  'mail delivery failed',
  'undelivered mail',
  'delivery status notification',
  'failure notice',
  'returned mail',
];

export class ImapInboxReader implements InboxReader {
  private buildClient(): ImapFlow {
    const host = process.env.IMAP_HOST;
    const port = Number(process.env.IMAP_PORT || 993);
    const secure = process.env.IMAP_SECURE !== 'false';
    const user = process.env.IMAP_USER;
    const pass = process.env.IMAP_PASS;

    if (!host || !user || !pass) {
      throw new Error(
        'IMAP is not configured. Set IMAP_HOST, IMAP_USER, IMAP_PASS in .env'
      );
    }

    return new ImapFlow({
      host,
      port,
      secure,
      auth: { user, pass },
      logger: false,
    });
  }

  async fetchNewMessages(sinceUid?: number): Promise<InboxMessageSummary[]> {
    const client = this.buildClient();
    const results: InboxMessageSummary[] = [];

    await client.connect();
    try {
      const lock = await client.getMailboxLock('INBOX');
      try {
        const range = sinceUid ? `${sinceUid + 1}:*` : '1:*';
        for await (const message of client.fetch(range, {
          envelope: true,
          source: true,
          uid: true,
        })) {
          const parsed = await simpleParser(message.source as Buffer);
          const subject = parsed.subject || '';
          const text = (parsed.text || '').slice(0, 500);
          const fromAddr = parsed.from?.text || '';
          const bodyLower = (parsed.text || '').toLowerCase();
          const subjectLower = subject.toLowerCase();

          const isBounce = BOUNCE_KEYWORDS.some(
            (kw) => subjectLower.includes(kw) || bodyLower.includes(kw)
          );

          results.push({
            uid: message.uid,
            from: fromAddr,
            subject,
            snippet: text,
            inReplyTo: parsed.inReplyTo,
            receivedAt: parsed.date || new Date(),
            isBounce,
          });
        }
      } finally {
        lock.release();
      }
    } finally {
      await client.logout();
    }

    return results;
  }
}
