import { getSupabaseServerClient } from '../supabase/server';
import { getInboxReader } from '../services/inbox-reader';

/**
 * Polls the mailbox for new messages and logs replies/bounces into
 * inbox_events. Matching a message back to a specific prospect/campaign
 * (e.g. via a tracking token in the subject or a References header) is
 * left as a Day 2 refinement — this establishes the plumbing.
 */
export async function syncInbox() {
  const supabase = getSupabaseServerClient();
  const reader = getInboxReader();

  // Track the last-seen UID in app_logs or a dedicated settings table later;
  // Day 1 just fetches recent messages each run.
  const messages = await reader.fetchNewMessages();

  for (const msg of messages) {
    await supabase.from('inbox_events').insert({
      type: msg.isBounce ? 'bounce' : 'reply',
      raw_snippet: msg.snippet,
      category: msg.isBounce ? 'bounce' : 'uncategorized',
      detected_at: msg.receivedAt.toISOString(),
    });
  }
}
