import { getSupabaseServerClient } from '../supabase/server';
import { getEmailSender } from '../services/email-sender';

/**
 * Processes due rows in send_queue.
 *
 * Day 1 keeps this deliberately simple (no sending-window/daily-limit
 * enforcement wired up yet) but the shape of the loop is where those
 * checks will slot in later:
 *   - skip if outside campaign.sending_window
 *   - skip if today's sent count >= campaign.daily_limit
 *   - skip if prospect.email is in suppression_list
 *   - add a random delay between sends
 */
export async function processQueue() {
  const supabase = getSupabaseServerClient();
  const sender = getEmailSender();

  const { data: dueItems, error } = await supabase
    .from('send_queue')
    .select('*, prospects(email), templates(subject, body)')
    .eq('status', 'pending')
    .lte('scheduled_at', new Date().toISOString())
    .limit(20);

  if (error) {
    console.error('[queue-processor] failed to fetch queue:', error.message);
    return;
  }

  for (const item of dueItems ?? []) {
    const email = item.prospects?.email;
    const subject = item.templates?.subject ?? '(no subject)';
    const body = item.templates?.body ?? '';

    if (!email) {
      await supabase
        .from('send_queue')
        .update({ status: 'error', error: 'missing prospect email' })
        .eq('id', item.id);
      continue;
    }

    const result = await sender.send({ to: email, subject, html: body });

    await supabase
      .from('send_queue')
      .update(
        result.success
          ? { status: 'sent', sent_at: new Date().toISOString() }
          : { status: 'error', error: result.error }
      )
      .eq('id', item.id);
  }
}
