/**
 * Standalone job runner. Portable by design:
 *
 *   Option A (Day 1, simplest): run this file as a long-lived process
 *     `npm run jobs`
 *   and let node-cron below handle scheduling internally. Works on any
 *   Node host, including a VPS or Hostinger Node.js hosting with a
 *   persistent process.
 *
 *   Option B: don't run this as a daemon at all — instead point your
 *   host's own crontab (or Hostinger's cron-job feature) at:
 *     node lib/jobs/runner.js --once
 *   which runs each job a single time and exits. Equally portable, and
 *   avoids needing a long-running process if your host doesn't support one.
 *
 * Neither option depends on Vercel Cron or any platform-specific scheduler.
 */

import cron from 'node-cron';
import { processQueue } from './queue-processor';
import { syncInbox } from './imap-sync';

const RUN_ONCE = process.argv.includes('--once');

async function runAll() {
  console.log(`[runner] ${new Date().toISOString()} running jobs...`);
  await processQueue().catch((e) => console.error('[queue-processor]', e));
  await syncInbox().catch((e) => console.error('[imap-sync]', e));
}

if (RUN_ONCE) {
  runAll().then(() => process.exit(0));
} else {
  // Every 5 minutes by default — adjust to taste once sending volume grows.
  cron.schedule('*/5 * * * *', runAll);
  console.log('[runner] scheduled jobs every 5 minutes (node-cron, in-process)');
  runAll(); // also run once immediately on startup
}
