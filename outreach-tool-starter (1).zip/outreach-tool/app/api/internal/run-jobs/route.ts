import { NextRequest, NextResponse } from 'next/server';
import { processQueue } from '../../../../lib/jobs/queue-processor';
import { syncInbox } from '../../../../lib/jobs/imap-sync';

// Force the Node.js runtime (not Edge) since jobs use nodemailer/imapflow,
// which need Node APIs. This keeps the route portable to any Node host.
export const runtime = 'nodejs';

/**
 * Alternative to lib/jobs/runner.ts for hosts that offer a
 * "hit this URL on a schedule" style cron (many shared hosts, including
 * Hostinger, do). Protect it with a shared secret so it can't be triggered
 * by anyone who finds the URL.
 */
export async function POST(req: NextRequest) {
  const secret = req.headers.get('x-internal-secret');
  if (!secret || secret !== process.env.INTERNAL_JOBS_SECRET) {
    return NextResponse.json({ error: 'unauthorized' }, { status: 401 });
  }

  await processQueue();
  await syncInbox();

  return NextResponse.json({ ok: true, ranAt: new Date().toISOString() });
}
