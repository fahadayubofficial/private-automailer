export const metadata = {
  title: 'Outreach Tool',
  description: 'Personal cold-outreach tool',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
