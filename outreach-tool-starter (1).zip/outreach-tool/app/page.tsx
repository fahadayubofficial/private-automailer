export default function Home() {
  return (
    <main style={{ padding: 40, fontFamily: 'system-ui' }}>
      <h1>Outreach Tool</h1>
      <p>Day 1 scaffold is running. Next steps:</p>
      <ol>
        <li>Fill in .env from .env.example</li>
        <li>Run the Supabase migration in supabase/migrations/0001_init.sql</li>
        <li>Build the first vertical slice: add prospect → template → send</li>
      </ol>
    </main>
  );
}
