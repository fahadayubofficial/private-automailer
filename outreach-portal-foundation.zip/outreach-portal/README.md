# Outreach Portal

Cold email outreach and campaign management. Next.js (App Router) + TypeScript + Tailwind + Supabase.
Host-neutral: no Vercel-specific APIs. Runs on Cloudflare first, then Hostinger.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in your Supabase values.
3. In the Supabase SQL Editor, run `supabase/migrations/0001_foundation.sql`.
4. In Supabase, go to Authentication > Users and add your login user (email + password).
5. `npm run dev` and open http://localhost:3000.

Checks: `npm run typecheck`, `npm run lint`, `npm run build`.

## Structure

- `app/(dashboard)/*` protected pages. Each section is a placeholder to replace with its real feature.
- `config/navigation.ts` sidebar items (single source of truth).
- `lib/supabase/*` browser, server, admin (service role, server-only) and middleware clients.
- `lib/services/<module>/index.ts` service interfaces. Put business logic here, not in components.
- `types/index.ts` shared types and status lists. Mirrors the CHECK constraints in the migration.
- `supabase/migrations/` numbered SQL files. Add new files (0002_...), never edit applied ones.

## Rules for parallel development

- Add code inside your module's folder; do not create second copies of shared types or services.
- Schema changes go in a new numbered migration.
- `SUPABASE_SERVICE_ROLE_KEY` is server-only. Never import `lib/supabase/admin.ts` from a client component.
