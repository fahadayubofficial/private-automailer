import { Card, CardBody } from "@/components/ui/Card";
import { PageContainer } from "@/components/layout/PageContainer";
import { navItems } from "@/config/navigation";

/**
 * Temporary page body for modules built by other developers.
 * Replace the page's contents with the real feature; keep using PageContainer.
 */
export function ModulePlaceholder({ href }: { href: string }) {
  const item = navItems.find((n) => n.href === href);
  const title = item?.label ?? "Coming soon";

  return (
    <PageContainer title={title} description={item?.description}>
      <Card>
        <CardBody>
          <p className="text-sm text-ink-soft">
            {title} isn&apos;t built yet. This page is a placeholder until the module is added.
          </p>
        </CardBody>
      </Card>
    </PageContainer>
  );
}
