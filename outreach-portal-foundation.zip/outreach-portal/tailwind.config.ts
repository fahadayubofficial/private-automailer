import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#16202A",
          soft: "#3C4A57",
          muted: "#6B7885",
        },
        canvas: "#F4F5F7",
        line: "#DDE1E6",
        rail: {
          DEFAULT: "#16202A",
          hover: "#213140",
          active: "#2B3F53",
          text: "#AEBBC7",
        },
        brand: {
          DEFAULT: "#2F5BEA",
          dark: "#2247C2",
          tint: "#E8EEFD",
        },
        signal: "#E8A317",
      },
      fontFamily: {
        sans: [
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "Helvetica Neue",
          "Arial",
          "sans-serif",
        ],
      },
    },
  },
  plugins: [],
};

export default config;
