-- 0001_foundation.sql
-- Core schema for the Outreach Portal. Run in Supabase SQL Editor or via
-- `supabase db push`. Safe to re-run: uses IF NOT EXISTS / OR REPLACE.
-- Tables owned by other modules contain only the minimum shared structure;
-- later changes go in NEW numbered migration files, never edit this one.

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Shared helpers
-- ---------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- profiles (application users, 1:1 with auth.users)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  email       text not null,
  full_name   text,
  role        text not null default 'admin' check (role in ('admin', 'member')),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, coalesce(new.email, ''), new.raw_user_meta_data ->> 'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- email_accounts (mailboxes). Passwords are stored ENCRYPTED by the app
-- (never plaintext) and are only read server-side with the service role.
-- ---------------------------------------------------------------------------
create table if not exists public.email_accounts (
  id                      uuid primary key default gen_random_uuid(),
  owner_id                uuid not null references public.profiles (id) on delete cascade,
  label                   text not null,
  from_email              text not null,
  from_name               text,
  smtp_host               text,
  smtp_port               integer check (smtp_port between 1 and 65535),
  smtp_secure             boolean not null default true,
  smtp_username           text,
  smtp_password_encrypted text,
  imap_host               text,
  imap_port               integer check (imap_port between 1 and 65535),
  imap_secure             boolean not null default true,
  imap_username           text,
  imap_password_encrypted text,
  daily_limit             integer not null default 30 check (daily_limit >= 0),
  is_active               boolean not null default true,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);
create index if not exists email_accounts_owner_idx on public.email_accounts (owner_id);
create unique index if not exists email_accounts_owner_from_uidx
  on public.email_accounts (owner_id, lower(from_email));

-- ---------------------------------------------------------------------------
-- email_templates
-- ---------------------------------------------------------------------------
create table if not exists public.email_templates (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  name        text not null,
  subject     text not null,
  body_html   text,
  body_text   text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists email_templates_owner_idx on public.email_templates (owner_id);

-- ---------------------------------------------------------------------------
-- prospects
-- ---------------------------------------------------------------------------
create table if not exists public.prospects (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null references public.profiles (id) on delete cascade,
  email          text not null check (position('@' in email) > 1),
  first_name     text,
  last_name      text,
  company        text,
  website        text,
  domain         text,
  job_title      text,
  status         text not null default 'new'
                 check (status in ('new','contacted','replied','interested','not_interested','bounced','unsubscribed')),
  source         text,
  custom_fields  jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create unique index if not exists prospects_owner_email_uidx on public.prospects (owner_id, lower(email));
create index if not exists prospects_owner_status_idx on public.prospects (owner_id, status);
create index if not exists prospects_owner_domain_idx on public.prospects (owner_id, domain);

-- ---------------------------------------------------------------------------
-- campaigns
-- ---------------------------------------------------------------------------
create table if not exists public.campaigns (
  id                uuid primary key default gen_random_uuid(),
  owner_id          uuid not null references public.profiles (id) on delete cascade,
  name              text not null,
  status            text not null default 'draft'
                    check (status in ('draft','scheduled','running','paused','completed','archived')),
  email_account_id  uuid references public.email_accounts (id) on delete set null,
  template_id       uuid references public.email_templates (id) on delete set null,
  settings          jsonb not null default '{}'::jsonb,
  started_at        timestamptz,
  completed_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists campaigns_owner_status_idx on public.campaigns (owner_id, status);

-- ---------------------------------------------------------------------------
-- campaign_prospects
-- ---------------------------------------------------------------------------
create table if not exists public.campaign_prospects (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references public.profiles (id) on delete cascade,
  campaign_id   uuid not null references public.campaigns (id) on delete cascade,
  prospect_id   uuid not null references public.prospects (id) on delete cascade,
  status        text not null default 'pending'
                check (status in ('pending','in_progress','completed','replied','bounced','removed')),
  current_step  integer not null default 0 check (current_step >= 0),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (campaign_id, prospect_id)
);
create index if not exists campaign_prospects_prospect_idx on public.campaign_prospects (prospect_id);
create index if not exists campaign_prospects_campaign_status_idx on public.campaign_prospects (campaign_id, status);

-- ---------------------------------------------------------------------------
-- followups (sequence steps per campaign)
-- ---------------------------------------------------------------------------
create table if not exists public.followups (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references public.profiles (id) on delete cascade,
  campaign_id   uuid not null references public.campaigns (id) on delete cascade,
  step_number   integer not null check (step_number >= 1),
  delay_days    integer not null default 3 check (delay_days >= 0),
  template_id   uuid references public.email_templates (id) on delete set null,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (campaign_id, step_number)
);

-- ---------------------------------------------------------------------------
-- email_messages (outbound queue/log and inbound replies)
-- ---------------------------------------------------------------------------
create table if not exists public.email_messages (
  id                uuid primary key default gen_random_uuid(),
  owner_id          uuid not null references public.profiles (id) on delete cascade,
  campaign_id       uuid references public.campaigns (id) on delete set null,
  prospect_id       uuid references public.prospects (id) on delete set null,
  email_account_id  uuid references public.email_accounts (id) on delete set null,
  template_id       uuid references public.email_templates (id) on delete set null,
  followup_id       uuid references public.followups (id) on delete set null,
  direction         text not null default 'outbound' check (direction in ('outbound','inbound')),
  status            text not null default 'queued'
                    check (status in ('queued','sending','sent','failed','bounced','received')),
  subject           text,
  body_html         text,
  body_text         text,
  message_id        text,
  in_reply_to       text,
  scheduled_at      timestamptz,
  sent_at           timestamptz,
  error             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
create index if not exists email_messages_queue_idx on public.email_messages (status, scheduled_at)
  where status = 'queued';
create index if not exists email_messages_owner_campaign_idx on public.email_messages (owner_id, campaign_id);
create index if not exists email_messages_prospect_idx on public.email_messages (prospect_id);
create index if not exists email_messages_message_id_idx on public.email_messages (message_id);

-- ---------------------------------------------------------------------------
-- suppressions (never email these addresses/domains)
-- ---------------------------------------------------------------------------
create table if not exists public.suppressions (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references public.profiles (id) on delete cascade,
  email       text,
  domain      text,
  reason      text not null default 'manual'
              check (reason in ('unsubscribed','bounced','complaint','manual','imported')),
  source      text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  check (email is not null or domain is not null)
);
create unique index if not exists suppressions_owner_email_uidx
  on public.suppressions (owner_id, lower(email)) where email is not null;
create unique index if not exists suppressions_owner_domain_uidx
  on public.suppressions (owner_id, lower(domain)) where domain is not null;

-- ---------------------------------------------------------------------------
-- analytics_events (append-only)
-- ---------------------------------------------------------------------------
create table if not exists public.analytics_events (
  id                uuid primary key default gen_random_uuid(),
  owner_id          uuid not null references public.profiles (id) on delete cascade,
  event_type        text not null
                    check (event_type in ('sent','delivered','opened','clicked','replied','bounced','unsubscribed','failed')),
  campaign_id       uuid references public.campaigns (id) on delete set null,
  prospect_id       uuid references public.prospects (id) on delete set null,
  email_message_id  uuid references public.email_messages (id) on delete set null,
  metadata          jsonb not null default '{}'::jsonb,
  occurred_at       timestamptz not null default now(),
  created_at        timestamptz not null default now()
);
create index if not exists analytics_events_owner_type_idx on public.analytics_events (owner_id, event_type, occurred_at desc);
create index if not exists analytics_events_campaign_idx on public.analytics_events (campaign_id, event_type);

-- ---------------------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------------------
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','email_accounts','email_templates','prospects','campaigns',
    'campaign_prospects','followups','email_messages','suppressions'
  ] loop
    execute format('drop trigger if exists set_updated_at on public.%I', t);
    execute format(
      'create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------------
-- Row Level Security: each user only sees their own rows.
-- The service role (server-only) bypasses RLS for background jobs.
-- ---------------------------------------------------------------------------
alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

do $$
declare t text;
begin
  foreach t in array array[
    'email_accounts','email_templates','prospects','campaigns','campaign_prospects',
    'followups','email_messages','suppressions','analytics_events'
  ] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "%s_owner_all" on public.%I', t, t);
    execute format(
      'create policy "%s_owner_all" on public.%I for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid())',
      t, t);
  end loop;
end $$;

-- Keep encrypted mailbox credentials unreadable from the browser/anon+user keys.
revoke select (smtp_password_encrypted, imap_password_encrypted)
  on public.email_accounts from anon, authenticated;
