/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Keep this file host-neutral. Do not add Vercel- or Cloudflare-specific
  // settings here; put host adapters in their own deploy config instead.
};

export default nextConfig;
