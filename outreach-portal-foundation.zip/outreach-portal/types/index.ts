/**
 * Shared domain types. Single source of truth: do not redefine these
 * elsewhere. Values mirror the CHECK constraints in
 * supabase/migrations/0001_foundation.sql.
 */

export const PROSPECT_STATUSES = [
  "new",
  "contacted",
  "replied",
  "interested",
  "not_interested",
  "bounced",
  "unsubscribed",
] as const;
export type ProspectStatus = (typeof PROSPECT_STATUSES)[number];

export const CAMPAIGN_STATUSES = ["draft", "scheduled", "running", "paused", "completed", "archived"] as const;
export type CampaignStatus = (typeof CAMPAIGN_STATUSES)[number];

export const CAMPAIGN_PROSPECT_STATUSES = ["pending", "in_progress", "completed", "replied", "bounced", "removed"] as const;
export type CampaignProspectStatus = (typeof CAMPAIGN_PROSPECT_STATUSES)[number];

export const EMAIL_STATUSES = ["queued", "sending", "sent", "failed", "bounced", "received"] as const;
export type EmailStatus = (typeof EMAIL_STATUSES)[number];

export const EMAIL_DIRECTIONS = ["outbound", "inbound"] as const;
export type EmailDirection = (typeof EMAIL_DIRECTIONS)[number];

export const SUPPRESSION_REASONS = ["unsubscribed", "bounced", "complaint", "manual", "imported"] as const;
export type SuppressionReason = (typeof SUPPRESSION_REASONS)[number];

export const ANALYTICS_EVENT_TYPES = ["sent", "delivered", "opened", "clicked", "replied", "bounced", "unsubscribed", "failed"] as const;
export type AnalyticsEventType = (typeof ANALYTICS_EVENT_TYPES)[number];

export type UserRole = "admin" | "member";

/** Application user profile (1:1 with auth.users). */
export interface User {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

/** Fields shared by every owned table row. */
interface OwnedRow {
  id: string;
  owner_id: string;
  created_at: string;
  updated_at: string;
}

export interface Prospect extends OwnedRow {
  email: string;
  first_name: string | null;
  last_name: string | null;
  company: string | null;
  website: string | null;
  domain: string | null;
  job_title: string | null;
  status: ProspectStatus;
  source: string | null;
  custom_fields: Record<string, unknown>;
}

export interface EmailAccount extends OwnedRow {
  label: string;
  from_email: string;
  from_name: string | null;
  smtp_host: string | null;
  smtp_port: number | null;
  smtp_secure: boolean;
  smtp_username: string | null;
  imap_host: string | null;
  imap_port: number | null;
  imap_secure: boolean;
  imap_username: string | null;
  daily_limit: number;
  is_active: boolean;
  // smtp/imap passwords are stored encrypted and are never part of client-facing types.
}

export interface EmailTemplate extends OwnedRow {
  name: string;
  subject: string;
  body_html: string | null;
  body_text: string | null;
}

export interface Campaign extends OwnedRow {
  name: string;
  status: CampaignStatus;
  email_account_id: string | null;
  template_id: string | null;
  settings: Record<string, unknown>;
  started_at: string | null;
  completed_at: string | null;
}

export interface CampaignProspect extends OwnedRow {
  campaign_id: string;
  prospect_id: string;
  status: CampaignProspectStatus;
  current_step: number;
}

export interface Followup extends OwnedRow {
  campaign_id: string;
  step_number: number;
  delay_days: number;
  template_id: string | null;
  is_active: boolean;
}

export interface EmailMessage extends OwnedRow {
  campaign_id: string | null;
  prospect_id: string | null;
  email_account_id: string | null;
  template_id: string | null;
  followup_id: string | null;
  direction: EmailDirection;
  status: EmailStatus;
  subject: string | null;
  body_html: string | null;
  body_text: string | null;
  message_id: string | null;
  in_reply_to: string | null;
  scheduled_at: string | null;
  sent_at: string | null;
  error: string | null;
}

export interface Suppression extends OwnedRow {
  email: string | null;
  domain: string | null;
  reason: SuppressionReason;
  source: string | null;
}

export interface AnalyticsEvent {
  id: string;
  owner_id: string;
  event_type: AnalyticsEventType;
  campaign_id: string | null;
  prospect_id: string | null;
  email_message_id: string | null;
  metadata: Record<string, unknown>;
  occurred_at: string;
  created_at: string;
}
