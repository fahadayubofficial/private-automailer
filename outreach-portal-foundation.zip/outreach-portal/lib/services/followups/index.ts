import type { Followup } from "@/types";
import type { ServiceContext } from "@/lib/services/database";

/** Owned by Account 3 (Email/Campaigns). Interface only. */

export interface FollowupService {
  listForCampaign(ctx: ServiceContext, campaignId: string): Promise<Followup[]>;
  saveStep(
    ctx: ServiceContext,
    input: Pick<Followup, "campaign_id" | "step_number" | "delay_days"> & Partial<Pick<Followup, "id" | "template_id" | "is_active">>
  ): Promise<Followup>;
  removeStep(ctx: ServiceContext, id: string): Promise<void>;
}
