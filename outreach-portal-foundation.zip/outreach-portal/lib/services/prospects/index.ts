import type { Prospect, ProspectStatus } from "@/types";
import type { Page, PageParams, ServiceContext } from "@/lib/services/database";

/** Owned by Account 2 (Prospects). Interface only; implement in this folder. */

export interface ProspectFilter extends PageParams {
  search?: string;
  status?: ProspectStatus;
}

export type ProspectInput = Pick<Prospect, "email"> &
  Partial<Pick<Prospect, "first_name" | "last_name" | "company" | "website" | "domain" | "job_title" | "status" | "source" | "custom_fields">>;

export interface ProspectService {
  list(ctx: ServiceContext, filter?: ProspectFilter): Promise<Page<Prospect>>;
  getById(ctx: ServiceContext, id: string): Promise<Prospect | null>;
  upsertMany(ctx: ServiceContext, inputs: ProspectInput[]): Promise<Prospect[]>;
  update(ctx: ServiceContext, id: string, patch: Partial<ProspectInput>): Promise<Prospect>;
  remove(ctx: ServiceContext, id: string): Promise<void>;
}
