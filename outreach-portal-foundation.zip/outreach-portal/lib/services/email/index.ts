import type { EmailAccount, EmailMessage, Suppression } from "@/types";
import type { Page, PageParams, ServiceContext } from "@/lib/services/database";

/**
 * Owned by Account 3 (Email/Campaigns). Interface only.
 * Covers mailboxes, message queue/log and the suppression list.
 */

export interface EmailAccountService {
  list(ctx: ServiceContext): Promise<EmailAccount[]>;
  getById(ctx: ServiceContext, id: string): Promise<EmailAccount | null>;
}

export interface OutgoingEmail {
  emailAccountId: string;
  to: string;
  subject: string;
  html?: string;
  text?: string;
  inReplyTo?: string;
}

export interface EmailSender {
  send(ctx: ServiceContext, email: OutgoingEmail): Promise<{ messageId: string }>;
}

export interface EmailMessageService {
  list(ctx: ServiceContext, params?: PageParams & { campaignId?: string; prospectId?: string }): Promise<Page<EmailMessage>>;
}

export interface SuppressionService {
  isSuppressed(ctx: ServiceContext, email: string): Promise<boolean>;
  add(ctx: ServiceContext, entry: Pick<Suppression, "reason"> & { email?: string; domain?: string; source?: string }): Promise<Suppression>;
  list(ctx: ServiceContext, params?: PageParams): Promise<Page<Suppression>>;
  remove(ctx: ServiceContext, id: string): Promise<void>;
}
