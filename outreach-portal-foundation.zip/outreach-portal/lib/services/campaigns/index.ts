import type { Campaign, CampaignStatus, EmailTemplate } from "@/types";
import type { Page, PageParams, ServiceContext } from "@/lib/services/database";

/** Owned by Account 3 (Email/Campaigns). Interface only. */

export interface CampaignService {
  list(ctx: ServiceContext, params?: PageParams & { status?: CampaignStatus }): Promise<Page<Campaign>>;
  getById(ctx: ServiceContext, id: string): Promise<Campaign | null>;
  create(ctx: ServiceContext, input: Pick<Campaign, "name"> & Partial<Pick<Campaign, "email_account_id" | "template_id" | "settings">>): Promise<Campaign>;
  setStatus(ctx: ServiceContext, id: string, status: CampaignStatus): Promise<Campaign>;
  addProspects(ctx: ServiceContext, campaignId: string, prospectIds: string[]): Promise<number>;
}

export interface TemplateService {
  list(ctx: ServiceContext): Promise<EmailTemplate[]>;
  getById(ctx: ServiceContext, id: string): Promise<EmailTemplate | null>;
  save(ctx: ServiceContext, input: Pick<EmailTemplate, "name" | "subject"> & Partial<Pick<EmailTemplate, "id" | "body_html" | "body_text">>): Promise<EmailTemplate>;
  remove(ctx: ServiceContext, id: string): Promise<void>;
}
