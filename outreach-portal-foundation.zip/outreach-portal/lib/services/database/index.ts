import type { SupabaseClient } from "@supabase/supabase-js";

/**
 * Shared database access contract for all service modules.
 *
 * Every service method takes a ServiceContext. Callers create it once at the
 * edge (route handler, server action, background job) so services never
 * import Next.js request APIs and stay portable/testable.
 *
 *  - User-facing code:   db = await createClient()      from "@/lib/supabase/server"
 *  - Background workers: db = createAdminClient()        from "@/lib/supabase/admin"
 */
export type Db = SupabaseClient;

export interface ServiceContext {
  db: Db;
  /** The auth user id that owns the data being accessed. */
  ownerId: string;
}

export interface Page<T> {
  items: T[];
  total: number;
}

export interface PageParams {
  page?: number;
  pageSize?: number;
}

export function pageRange({ page = 1, pageSize = 25 }: PageParams) {
  const size = Math.min(Math.max(pageSize, 1), 200);
  const from = (Math.max(page, 1) - 1) * size;
  return { from, to: from + size - 1 };
}
