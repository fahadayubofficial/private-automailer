import type { AnalyticsEvent, AnalyticsEventType } from "@/types";
import type { ServiceContext } from "@/lib/services/database";

/** Owned by Account 4 (Analytics/Infrastructure). Interface only. */

export type AnalyticsEventInput = Pick<AnalyticsEvent, "event_type"> &
  Partial<Pick<AnalyticsEvent, "campaign_id" | "prospect_id" | "email_message_id" | "metadata" | "occurred_at">>;

export interface AnalyticsSummary {
  counts: Partial<Record<AnalyticsEventType, number>>;
}

export interface AnalyticsService {
  record(ctx: ServiceContext, event: AnalyticsEventInput): Promise<void>;
  summary(ctx: ServiceContext, params?: { campaignId?: string; since?: string }): Promise<AnalyticsSummary>;
}
