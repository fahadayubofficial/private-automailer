/**
 * Central environment access.
 *
 * - getPublicEnv(): safe anywhere (browser or server).
 * - getServerEnv(): server-only values. Never import this file's server helper
 *   from a client component.
 *
 * NEXT_PUBLIC_* variables must be referenced literally (not via dynamic keys)
 * so Next.js can inline them into the browser bundle.
 */

export function getPublicEnv() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. Copy .env.example to .env.local and fill them in."
    );
  }

  return { supabaseUrl, supabaseAnonKey };
}

export function getServerEnv() {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!serviceRoleKey) {
    throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY (server-only).");
  }

  return { ...getPublicEnv(), serviceRoleKey };
}
