import "server-only";
import { createClient } from "@supabase/supabase-js";
import { getServerEnv } from "@/lib/env";

/**
 * Service-role Supabase client. BYPASSES Row Level Security.
 *
 * Server-only: the "server-only" import makes the build fail if this file is
 * ever pulled into a client component. Use only for trusted background work
 * (queues, IMAP sync, webhooks), never with unvalidated user input as filters.
 */
export function createAdminClient() {
  const { supabaseUrl, serviceRoleKey } = getServerEnv();
  return createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
