/**
 * Only allow same-site relative paths as post-login redirect targets.
 * Blocks absolute URLs and protocol-relative ("//evil.com") paths.
 */
export function safeRedirectPath(value: string | null | undefined, fallback = "/dashboard"): string {
  if (!value) return fallback;
  if (!value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) {
    return fallback;
  }
  return value;
}
