import type { Metadata } from "next";
import Link from "next/link";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { PageContainer } from "@/components/layout/PageContainer";
import { Table, TBody, Td, Th, THead, Tr } from "@/components/ui/Table";
import { navItems } from "@/config/navigation";

export const metadata: Metadata = { title: "Dashboard" };

// Real numbers come from lib/services/analytics (Account 4).
const stats = ["Prospects", "Active campaigns", "Emails sent", "Replies"];

export default function DashboardPage() {
  const shortcuts = navItems.filter((n) => n.href !== "/dashboard" && n.href !== "/settings");

  return (
    <PageContainer title="Dashboard" description="Overview of your outreach.">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((label) => (
          <Card key={label}>
            <CardBody>
              <p className="text-sm text-ink-muted">{label}</p>
              <p className="mt-2 text-2xl font-semibold text-ink">–</p>
            </CardBody>
          </Card>
        ))}
      </div>

      <Card className="mt-6">
        <CardHeader title="Modules" description="Sections that will be filled in as they are built." />
        <Table>
          <THead>
            <Tr>
              <Th>Section</Th>
              <Th>Purpose</Th>
            </Tr>
          </THead>
          <TBody>
            {shortcuts.map((item) => (
              <Tr key={item.href}>
                <Td>
                  <Link href={item.href} className="font-medium text-brand hover:underline">
                    {item.label}
                  </Link>
                </Td>
                <Td className="text-ink-soft">{item.description}</Td>
              </Tr>
            ))}
          </TBody>
        </Table>
      </Card>
    </PageContainer>
  );
}
