import type { ReactNode } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { requireUser } from "@/lib/auth/session";

// Defense in depth: middleware already redirects, this guards every dashboard page.
export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  return <AppShell email={user.email ?? ""}>{children}</AppShell>;
}
