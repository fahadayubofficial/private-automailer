import type { Metadata } from "next";
import { Suspense } from "react";
import { LoginForm } from "./login-form";
import { siteConfig } from "@/config/site";

export const metadata: Metadata = { title: "Sign in" };

export default function LoginPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center gap-2">
          <span aria-hidden className="h-3 w-3 rounded-full bg-signal" />
          <span className="text-lg font-semibold text-ink">{siteConfig.name}</span>
        </div>
        <h1 className="mb-1 text-2xl font-semibold text-ink">Sign in</h1>
        <p className="mb-6 text-sm text-ink-muted">Use the account created in your Supabase project.</p>
        <Suspense>
          <LoginForm />
        </Suspense>
      </div>
    </main>
  );
}
