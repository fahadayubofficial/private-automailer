import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/** Public liveness check for hosting/uptime monitors. Exposes no secrets. */
export function GET() {
  return NextResponse.json({ status: "ok" });
}
