import { redirect } from "next/navigation";

// Middleware sends signed-out visitors to /login; signed-in users land here.
export default function Home() {
  redirect("/dashboard");
}
