export type NavItem = {
  label: string;
  href: string;
  description: string;
};

/**
 * Single source of truth for sidebar navigation.
 * Accounts 2-4: replace the placeholder page at each href; do not add
 * duplicate routes or change these paths without coordinating.
 */
export const navItems: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", description: "Overview of your outreach." },
  { label: "Prospects", href: "/prospects", description: "Your prospect database." },
  { label: "Import", href: "/import", description: "Bring prospects in from CSV." },
  { label: "Campaigns", href: "/campaigns", description: "Create and run campaigns." },
  { label: "Templates", href: "/templates", description: "Reusable email templates." },
  { label: "Email Accounts", href: "/email-accounts", description: "Mailboxes used for sending." },
  { label: "Follow-ups", href: "/follow-ups", description: "Automatic follow-up sequences." },
  { label: "Analytics", href: "/analytics", description: "Sends, replies and bounces." },
  { label: "Suppression List", href: "/suppression-list", description: "Addresses you will never email." },
  { label: "Settings", href: "/settings", description: "Account and app preferences." },
];
