export const siteConfig = {
  name: "Outreach Portal",
  description: "Cold email outreach and campaign management.",
} as const;
